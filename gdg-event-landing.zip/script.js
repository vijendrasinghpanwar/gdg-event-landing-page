function register() {
  alert("Registration successful! (Demo)");
}

const eventDate = new Date("January 22, 2026 11:00:00").getTime();
const timer = document.getElementById("timer");

setInterval(() => {
  const now = new Date().getTime();
  const diff = eventDate - now;

  if (diff < 0) {
    timer.innerHTML = "Event Started!";
    return;
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);

  timer.innerHTML = `${days}d ${hours}h ${minutes}m`;
}, 1000);

document.getElementById("themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
});
